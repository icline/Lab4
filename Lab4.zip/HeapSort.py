import sys
from typing import List

# Applies heap sort algorithm to a list of numbers 
class HeapSort:
    # Create Node class to store data, and left and right
    # subtree 
    class Node:
        def __init__(self, data=0):
            self.data = data
            self.left = None
            self.right = None

    # Constructor that initializes a heap and list of numbers
    # to be sorted
    def __init__(self, array):
        self.array = array
        self.root = None

    # Heapifies the heap
    def heapify(self):
        # Creates a Min Heap
        last_non_leaf = (len(self.array)//2) - 1
        for i in range(last_non_leaf, -1, -1):
            heapifying = True
            index = i
            while heapifying is True:
                biggest = index
                left_child = 2*index + 1
                right_child = (2*index) + 2

                bigger_nodes = 0
                if len(self.array) > left_child and \
                    self.array[left_child] < self.array[index]:
                    biggest = left_child
                    bigger_nodes += 1

                if len(self.array) > right_child and \
                    self.array[right_child] < self.array[biggest]:
                    biggest = right_child
                    bigger_nodes += 1
                
                if bigger_nodes > 0:
                    self.array[index], self.array[biggest] = \
                        self.array[biggest], self.array[index]
                    index = biggest
                    bigger_nodes = 0
                else:
                    heapifying = False

    # Sorts a list of numbers using heap sort
    def heap_sort(self):
        # Create Heap
        self.heapify()

        # Sort
        sorted_array = []
        while self.array:
            self.array[0], self.array[-1] = self.array[-1], self.array[0]
            sorted_array.append(self.array.pop())
            self.heapify()

        return sorted_array

